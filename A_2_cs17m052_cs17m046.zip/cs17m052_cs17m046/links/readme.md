Crawled Data-----1)crawled_links.txt


Collected Data----2)ben-bd_web_2014_100K-sources.txt
					ben_newscrawl_2011_100K-sources.txt
					ben_newscrawl_2015_1M-sources.txt
					ben_newscrawl_2017_1M-sources.txt
					ben_wikipedia_2011_100K-sources.txt
					ben_wikipedia_2016_30K-sources.txt
					https://www.isical.ac.in/~lru/downloadCorpus.html

Shared data--------3)shared.txt 	(Shared by  EE17S019 MAITREYA SUIN )